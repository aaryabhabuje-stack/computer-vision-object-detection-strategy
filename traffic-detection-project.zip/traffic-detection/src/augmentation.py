"""
Training-time data augmentation.

Implements Section 7 of the project strategy document: horizontal flip,
rotation, scaling, random/mosaic cropping, and brightness/contrast jitter.
Only used on the training split, never at inference time.

Boxes are represented throughout as an (N, 5) float array of absolute pixel
coordinates: ``[x1, y1, x2, y2, class_id]``. Every geometric transform below
updates the boxes in lock-step with the image -- this is the exact bug
called out in the strategy document's Section 7 note (a box left unmodified
after its image is rotated silently corrupts the label).
"""
from __future__ import annotations

import random

import cv2
import numpy as np

FILL_COLOR = (114, 114, 114)


def horizontal_flip(image: np.ndarray, boxes: np.ndarray):
    w = image.shape[1]
    flipped = cv2.flip(image, 1)
    boxes = boxes.copy()
    boxes[:, [0, 2]] = w - boxes[:, [2, 0]]
    return flipped, boxes


def rotate(image: np.ndarray, boxes: np.ndarray, max_angle: float = 15.0):
    h, w = image.shape[:2]
    angle = random.uniform(-max_angle, max_angle)
    matrix = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    rotated = cv2.warpAffine(image, matrix, (w, h), borderValue=FILL_COLOR)

    new_boxes = boxes.copy().astype(np.float32)
    for i, (x1, y1, x2, y2, _cls) in enumerate(boxes):
        corners = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]], dtype=np.float32)
        ones = np.ones((4, 1), dtype=np.float32)
        transformed = (matrix @ np.hstack([corners, ones]).T).T
        new_boxes[i, 0] = transformed[:, 0].min()
        new_boxes[i, 1] = transformed[:, 1].min()
        new_boxes[i, 2] = transformed[:, 0].max()
        new_boxes[i, 3] = transformed[:, 1].max()
    return rotated, new_boxes


def scale_transform(image: np.ndarray, boxes: np.ndarray, scale_range=(0.8, 1.2)):
    factor = random.uniform(*scale_range)
    h, w = image.shape[:2]
    new_w, new_h = max(int(w * factor), 1), max(int(h * factor), 1)
    resized = cv2.resize(image, (new_w, new_h))
    boxes = boxes.copy().astype(np.float32)

    if factor <= 1.0:
        canvas = np.full((h, w, 3), FILL_COLOR, dtype=np.uint8)
        off_x, off_y = (w - new_w) // 2, (h - new_h) // 2
        canvas[off_y : off_y + new_h, off_x : off_x + new_w] = resized
        boxes[:, [0, 2]] = boxes[:, [0, 2]] * factor + off_x
        boxes[:, [1, 3]] = boxes[:, [1, 3]] * factor + off_y
    else:
        off_x, off_y = (new_w - w) // 2, (new_h - h) // 2
        canvas = resized[off_y : off_y + h, off_x : off_x + w]
        boxes[:, [0, 2]] = boxes[:, [0, 2]] * factor - off_x
        boxes[:, [1, 3]] = boxes[:, [1, 3]] * factor - off_y
    return canvas, boxes


def random_crop(image: np.ndarray, boxes: np.ndarray, min_visibility: float = 0.4):
    h, w = image.shape[:2]
    crop_w = max(int(w * random.uniform(0.7, 1.0)), 1)
    crop_h = max(int(h * random.uniform(0.7, 1.0)), 1)
    x0 = random.randint(0, w - crop_w)
    y0 = random.randint(0, h - crop_h)

    cropped = cv2.resize(image[y0 : y0 + crop_h, x0 : x0 + crop_w], (w, h))
    sx, sy = w / crop_w, h / crop_h

    kept = []
    for x1, y1, x2, y2, cls in boxes:
        nx1, ny1 = max(x1 - x0, 0), max(y1 - y0, 0)
        nx2, ny2 = min(x2 - x0, crop_w), min(y2 - y0, crop_h)
        if nx2 <= nx1 or ny2 <= ny1:
            continue
        orig_area = (x2 - x1) * (y2 - y1)
        vis_area = (nx2 - nx1) * (ny2 - ny1)
        if orig_area > 0 and (vis_area / orig_area) < min_visibility:
            continue
        kept.append([nx1 * sx, ny1 * sy, nx2 * sx, ny2 * sy, cls])

    new_boxes = np.array(kept, dtype=np.float32) if kept else np.zeros((0, 5), dtype=np.float32)
    return cropped, new_boxes


def brightness_contrast(image: np.ndarray, brightness_range=(-0.2, 0.2), contrast_range=(0.8, 1.2)):
    brightness = random.uniform(*brightness_range) * 255
    contrast = random.uniform(*contrast_range)
    jittered = image.astype(np.float32) * contrast + brightness
    return np.clip(jittered, 0, 255).astype(np.uint8)


def mosaic(images: list[np.ndarray], boxes_list: list[np.ndarray], output_size: int = 640):
    """Combine 4 images into one composite tile (YOLO-style mosaic augmentation)."""
    assert len(images) == 4 and len(boxes_list) == 4, "mosaic() requires exactly 4 images"
    cx, cy = output_size // 2, output_size // 2
    canvas = np.full((output_size, output_size, 3), FILL_COLOR, dtype=np.uint8)
    placements = [
        (0, 0, cx, cy),
        (cx, 0, output_size, cy),
        (0, cy, cx, output_size),
        (cx, cy, output_size, output_size),
    ]

    all_boxes = []
    for img, boxes, (px1, py1, px2, py2) in zip(images, boxes_list, placements):
        tile_w, tile_h = px2 - px1, py2 - py1
        resized = cv2.resize(img, (tile_w, tile_h))
        canvas[py1:py2, px1:px2] = resized
        sx, sy = tile_w / img.shape[1], tile_h / img.shape[0]
        for x1, y1, x2, y2, cls in boxes:
            all_boxes.append([x1 * sx + px1, y1 * sy + py1, x2 * sx + px1, y2 * sy + py1, cls])

    boxes_out = np.array(all_boxes, dtype=np.float32) if all_boxes else np.zeros((0, 5), dtype=np.float32)
    return canvas, boxes_out


def augment(image: np.ndarray, boxes: np.ndarray, mosaic_pool: list | None = None):
    """Apply the full augmentation stack from Section 7, each gated by its
    own probability, matching the pseudocode in Section 10.2 of the
    strategy document.
    """
    if random.random() < 0.5:
        image, boxes = horizontal_flip(image, boxes)
    if random.random() < 0.5:
        image, boxes = rotate(image, boxes)
    if random.random() < 0.5:
        image, boxes = scale_transform(image, boxes)
    if random.random() < 0.3 and len(boxes) > 0:
        image, boxes = random_crop(image, boxes)
    if random.random() < 0.5:
        image = brightness_contrast(image)
    if mosaic_pool and random.random() < 0.5 and len(mosaic_pool) >= 3:
        others = random.sample(mosaic_pool, 3)
        imgs = [image] + [o[0] for o in others]
        boxes_list = [boxes] + [o[1] for o in others]
        image, boxes = mosaic(imgs, boxes_list)
    return image, boxes
