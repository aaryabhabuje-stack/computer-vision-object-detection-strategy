"""
Post-processing: confidence filtering, IoU, and Non-Max Suppression.

Implements Sections 10.5 and 11.2-11.4 of the project strategy document.
Boxes are (N, 4) arrays in absolute pixel xyxy format unless noted otherwise.
"""
from __future__ import annotations

import numpy as np


def iou(box_a: np.ndarray, box_b: np.ndarray) -> float:
    """Intersection-over-Union between two xyxy boxes (Section 11.3)."""
    xa = max(box_a[0], box_b[0])
    ya = max(box_a[1], box_b[1])
    xb = min(box_a[2], box_b[2])
    yb = min(box_a[3], box_b[3])

    inter = max(0.0, xb - xa) * max(0.0, yb - ya)
    area_a = max(0.0, box_a[2] - box_a[0]) * max(0.0, box_a[3] - box_a[1])
    area_b = max(0.0, box_b[2] - box_b[0]) * max(0.0, box_b[3] - box_b[1])
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def non_max_suppression(boxes: np.ndarray, scores: np.ndarray, iou_thresh: float = 0.45) -> list[int]:
    """Greedy NMS (Section 11.4): keep the highest-confidence box, drop every
    remaining box that overlaps it above ``iou_thresh``, repeat. Returns the
    indices (into the original ``boxes``/``scores`` arrays) that survive.
    """
    order = scores.argsort()[::-1]
    keep: list[int] = []
    while len(order) > 0:
        current = order[0]
        keep.append(int(current))
        remaining = order[1:]
        if len(remaining) == 0:
            break
        ious = np.array([iou(boxes[current], boxes[i]) for i in remaining])
        order = remaining[ious <= iou_thresh]
    return keep


def filter_by_confidence(
    boxes: np.ndarray, scores: np.ndarray, class_ids: np.ndarray, conf_thresh: float = 0.4
):
    """Drop predictions whose confidence falls below ``conf_thresh`` (Section 11.2)."""
    mask = scores >= conf_thresh
    return boxes[mask], scores[mask], class_ids[mask]


def rescale_to_original(boxes: np.ndarray, scale: float, pad_offset: tuple[int, int]) -> np.ndarray:
    """Undo the letterbox resize from ``preprocessing.letterbox_resize`` so
    detection boxes line up with the original, un-padded frame.
    """
    pad_x, pad_y = pad_offset
    boxes = boxes.copy().astype(np.float32)
    boxes[:, [0, 2]] = (boxes[:, [0, 2]] - pad_x) / scale
    boxes[:, [1, 3]] = (boxes[:, [1, 3]] - pad_y) / scale
    return boxes


def postprocess(
    raw_boxes: np.ndarray,
    raw_scores: np.ndarray,
    raw_class_ids: np.ndarray,
    scale: float,
    pad_offset: tuple[int, int],
    conf_thresh: float = 0.4,
    iou_thresh: float = 0.45,
):
    """Full post-processing chain matching Section 10.4's ``infer()`` pseudocode:
    confidence filter -> NMS -> rescale to original frame coordinates.
    """
    boxes, scores, class_ids = filter_by_confidence(raw_boxes, raw_scores, raw_class_ids, conf_thresh)
    if len(boxes) == 0:
        return boxes, scores, class_ids

    keep = non_max_suppression(boxes, scores, iou_thresh)
    boxes, scores, class_ids = boxes[keep], scores[keep], class_ids[keep]
    boxes = rescale_to_original(boxes, scale, pad_offset)
    return boxes, scores, class_ids
