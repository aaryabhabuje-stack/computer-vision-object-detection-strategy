"""
Preprocessing pipeline shared by training and inference.

Implements Section 6 of the project strategy document:
  1. Letterbox resize to a fixed square input, preserving aspect ratio.
  2. Selective denoising / CLAHE contrast enhancement for low-light frames.
  3. Normalization to [0, 1].
  4. Conversion to a CHW tensor layout.

Every function here is deterministic and framework-agnostic (pure NumPy /
OpenCV) so the exact same code path can run at training time and at
inference time, which is the guarantee the strategy document calls for.
"""
from __future__ import annotations

import cv2
import numpy as np


def letterbox_resize(
    image: np.ndarray,
    target_size: int = 640,
    fill_color: tuple[int, int, int] = (114, 114, 114),
) -> tuple[np.ndarray, float, tuple[int, int]]:
    """Resize ``image`` so its longer side equals ``target_size``, then pad
    the shorter side with ``fill_color`` to make it square.

    Returns the padded image plus the scale factor and (pad_x, pad_y) offset
    needed to map detections back to the original image coordinates later
    (see :func:`postprocessing.rescale_to_original`).
    """
    h, w = image.shape[:2]
    scale = target_size / max(h, w)
    new_w, new_h = int(round(w * scale)), int(round(h * scale))
    resized = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

    padded = np.full((target_size, target_size, 3), fill_color, dtype=np.uint8)
    pad_x = (target_size - new_w) // 2
    pad_y = (target_size - new_h) // 2
    padded[pad_y : pad_y + new_h, pad_x : pad_x + new_w] = resized
    return padded, scale, (pad_x, pad_y)


def denoise_if_needed(image: np.ndarray, brightness_threshold: float = 40.0) -> np.ndarray:
    """Apply CLAHE contrast enhancement + a light Gaussian blur to frames
    that are flagged as under-exposed / noisy (mean brightness below
    ``brightness_threshold``). Well-lit frames pass through untouched.
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if gray.mean() >= brightness_threshold:
        return image

    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_channel = clahe.apply(l_channel)
    enhanced = cv2.cvtColor(cv2.merge((l_channel, a_channel, b_channel)), cv2.COLOR_LAB2BGR)
    return cv2.GaussianBlur(enhanced, (3, 3), 0)


def normalize(image: np.ndarray) -> np.ndarray:
    """Scale uint8 pixel values in [0, 255] to float32 in [0, 1]."""
    return image.astype(np.float32) / 255.0


def to_chw_tensor(image: np.ndarray) -> np.ndarray:
    """Convert an HWC image array to CHW layout expected by the model."""
    return np.transpose(image, (2, 0, 1))


def preprocess(image: np.ndarray, target_size: int = 640):
    """Full preprocessing pipeline: denoise -> letterbox -> normalize -> CHW.

    Returns ``(tensor, scale, pad_offset)``. ``scale`` and ``pad_offset`` are
    required later to map model output boxes back to the original frame's
    pixel coordinates.
    """
    image = denoise_if_needed(image)
    padded, scale, pad_offset = letterbox_resize(image, target_size)
    tensor = to_chw_tensor(normalize(padded))
    return tensor, scale, pad_offset
