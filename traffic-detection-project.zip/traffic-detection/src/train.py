"""
Training entry point.

Implements the hyperparameters and recipe from Section 8 of the project
strategy document: SGD optimizer, cosine LR decay from 0.01, 3-epoch warm-up
(handled internally by Ultralytics), COCO-pretrained initialization, and
early stopping with patience 20.

Requires: pip install ultralytics (see requirements.txt). The import is
deliberately deferred into main() so the rest of this codebase (preprocessing,
augmentation, postprocessing, tests) works even in an environment where
torch/ultralytics is not installed.

Usage:
    python src/train.py --config configs/traffic.yaml
    python src/train.py --config configs/traffic.yaml --epochs 60 --batch 8
"""
from __future__ import annotations

import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="Train YOLOv8n on the traffic-surveillance dataset.")
    parser.add_argument("--config", default="configs/traffic.yaml", help="dataset YAML (Section 5)")
    parser.add_argument("--weights", default="yolov8n.pt", help="starting weights (COCO-pretrained)")
    parser.add_argument("--epochs", type=int, default=120)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--lr0", type=float, default=0.01)
    parser.add_argument("--patience", type=int, default=20, help="early-stopping patience")
    parser.add_argument("--freeze", type=int, default=10, help="freeze first N backbone layers for warm-up")
    parser.add_argument("--project", default="runs", help="directory to write training runs to")
    parser.add_argument("--name", default="traffic-yolov8n")
    return parser.parse_args()


def main():
    args = parse_args()

    try:
        from ultralytics import YOLO
    except ImportError as exc:  # pragma: no cover - environment guard
        raise SystemExit(
            "ultralytics is not installed. Run `pip install -r requirements.txt` first."
        ) from exc

    model = YOLO(args.weights)
    model.train(
        data=args.config,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        lr0=args.lr0,
        optimizer="SGD",
        momentum=0.937,
        weight_decay=5e-4,
        warmup_epochs=3,
        patience=args.patience,
        freeze=args.freeze,
        project=args.project,
        name=args.name,
    )


if __name__ == "__main__":
    main()
