"""Small shared helpers used by train.py and infer.py."""
from __future__ import annotations

import cv2
import yaml


def load_class_names(config_path: str) -> dict:
    """Read the ``names`` mapping out of a YOLO-style dataset YAML (Section 5.1)."""
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)
    return cfg.get("names", {})


def draw_detections(frame, boxes, class_names: dict):
    """Draw Ultralytics ``Boxes`` results onto ``frame`` for visual inspection."""
    for box in boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        cls_id = int(box.cls[0])
        conf = float(box.conf[0])
        label = f"{class_names.get(cls_id, cls_id)} {conf:.2f}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 200, 0), 2)
        text_y = max(y1 - 6, 12)
        cv2.putText(frame, label, (x1, text_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 0), 1, cv2.LINE_AA)
    return frame
