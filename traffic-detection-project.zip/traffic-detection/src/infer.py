"""
Real-time inference entry point.

Implements the deployment-side pipeline from Sections 9-10 of the project
strategy document: read frames from a camera/video source, run YOLOv8n at
the configured confidence/IoU thresholds, and overlay the resulting boxes.

Usage:
    python src/infer.py --weights runs/traffic-yolov8n/weights/best.pt --source 0
    python src/infer.py --weights best.pt --source path/to/video.mp4 --conf 0.4 --iou 0.45
"""
from __future__ import annotations

import argparse

import cv2

from utils import draw_detections, load_class_names


def parse_args():
    parser = argparse.ArgumentParser(description="Run real-time YOLOv8n traffic detection.")
    parser.add_argument("--weights", default="best.pt")
    parser.add_argument("--source", default="0", help="camera index or video file path")
    parser.add_argument("--conf", type=float, default=0.4, help="confidence threshold (Section 11.2)")
    parser.add_argument("--iou", type=float, default=0.45, help="NMS IoU threshold (Section 11.4)")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--config", default="configs/traffic.yaml")
    parser.add_argument("--headless", action="store_true", help="skip cv2.imshow (for servers without a display)")
    return parser.parse_args()


def main():
    args = parse_args()

    try:
        from ultralytics import YOLO
    except ImportError as exc:  # pragma: no cover - environment guard
        raise SystemExit(
            "ultralytics is not installed. Run `pip install -r requirements.txt` first."
        ) from exc

    model = YOLO(args.weights)
    class_names = load_class_names(args.config)

    source = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"Could not open video source: {args.source}")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        results = model.predict(frame, conf=args.conf, iou=args.iou, imgsz=args.imgsz, verbose=False)[0]
        frame = draw_detections(frame, results.boxes, class_names)

        if not args.headless:
            cv2.imshow("Traffic Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
