"""Unit tests for src/postprocessing.py (Section 13.1 'Unit -- NMS correctness')."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from postprocessing import (  # noqa: E402
    filter_by_confidence,
    iou,
    non_max_suppression,
    postprocess,
    rescale_to_original,
)


def test_iou_identical_boxes():
    box = np.array([0, 0, 10, 10], dtype=np.float32)
    assert abs(iou(box, box) - 1.0) < 1e-6


def test_iou_no_overlap():
    a = np.array([0, 0, 10, 10], dtype=np.float32)
    b = np.array([20, 20, 30, 30], dtype=np.float32)
    assert iou(a, b) == 0.0


def test_iou_partial_overlap():
    a = np.array([0, 0, 10, 10], dtype=np.float32)
    b = np.array([5, 5, 15, 15], dtype=np.float32)
    expected = 25.0 / 175.0  # intersection 5x5=25, union 100+100-25=175
    assert abs(iou(a, b) - expected) < 1e-6


def test_nms_removes_duplicate_keeps_distinct_object():
    boxes = np.array(
        [
            [0, 0, 10, 10],   # object A, box 1
            [0, 0, 10, 9],    # object A, near-duplicate box (should be suppressed)
            [50, 50, 60, 60],  # object B, distinct
        ],
        dtype=np.float32,
    )
    scores = np.array([0.9, 0.8, 0.95], dtype=np.float32)
    keep = non_max_suppression(boxes, scores, iou_thresh=0.5)
    assert set(keep) == {2, 0}  # highest-confidence box of each object survives


def test_confidence_filter_drops_low_scores():
    boxes = np.array([[0, 0, 1, 1], [0, 0, 1, 1]], dtype=np.float32)
    scores = np.array([0.9, 0.1], dtype=np.float32)
    class_ids = np.array([0, 1])
    b, s, _c = filter_by_confidence(boxes, scores, class_ids, conf_thresh=0.4)
    assert len(b) == 1 and s[0] == 0.9


def test_rescale_to_original_undoes_letterbox():
    boxes = np.array([[110.0, 60.0, 210.0, 160.0]], dtype=np.float32)
    rescaled = rescale_to_original(boxes, scale=0.5, pad_offset=(10, 10))
    assert np.allclose(rescaled[0], [200.0, 100.0, 400.0, 300.0])


def test_full_postprocess_pipeline():
    boxes = np.array(
        [[110, 60, 210, 160], [111, 61, 211, 161], [400, 400, 420, 420]], dtype=np.float32
    )
    scores = np.array([0.9, 0.85, 0.2], dtype=np.float32)  # last one below default conf_thresh
    class_ids = np.array([0, 0, 4])
    boxes_out, scores_out, class_ids_out = postprocess(
        boxes, scores, class_ids, scale=0.5, pad_offset=(10, 10), conf_thresh=0.4, iou_thresh=0.45
    )
    assert len(boxes_out) == 1  # low-confidence box dropped, duplicate suppressed
    assert scores_out[0] == 0.9
    assert class_ids_out[0] == 0


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS: {t.__name__}")
    print(f"\n{len(tests)} postprocessing tests passed.")
