"""Unit tests for src/preprocessing.py (Section 13.1 'Unit -- preprocessing')."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from preprocessing import letterbox_resize, normalize, preprocess  # noqa: E402


def test_letterbox_square_output():
    img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
    padded, _scale, _pad = letterbox_resize(img, target_size=640)
    assert padded.shape == (640, 640, 3)


def test_letterbox_preserves_aspect_ratio_via_padding():
    # Very wide image: padding should land on top/bottom, not left/right.
    img = np.random.randint(0, 255, (200, 800, 3), dtype=np.uint8)
    _padded, _scale, (pad_x, pad_y) = letterbox_resize(img, target_size=640)
    assert pad_y > 0 and pad_x == 0


def test_letterbox_tall_image_pads_sides():
    img = np.random.randint(0, 255, (800, 200, 3), dtype=np.uint8)
    _padded, _scale, (pad_x, pad_y) = letterbox_resize(img, target_size=640)
    assert pad_x > 0 and pad_y == 0


def test_normalize_range():
    img = np.array([[[0, 128, 255]]], dtype=np.uint8)
    norm = normalize(img)
    assert norm.min() >= 0.0 and norm.max() <= 1.0


def test_full_preprocess_shape_and_range():
    img = np.random.randint(0, 255, (720, 1280, 3), dtype=np.uint8)
    tensor, scale, pad = preprocess(img, target_size=640)
    assert tensor.shape == (3, 640, 640)
    assert tensor.min() >= 0.0 and tensor.max() <= 1.0
    assert scale > 0
    assert len(pad) == 2


def test_preprocess_denoises_dark_frame_without_crashing():
    dark_img = np.random.randint(0, 20, (480, 640, 3), dtype=np.uint8)  # near-black frame
    tensor, _scale, _pad = preprocess(dark_img, target_size=640)
    assert tensor.shape == (3, 640, 640)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS: {t.__name__}")
    print(f"\n{len(tests)} preprocessing tests passed.")
