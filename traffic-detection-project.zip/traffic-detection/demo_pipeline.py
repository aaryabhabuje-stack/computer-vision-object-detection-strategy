"""
Dependency-light demo of the non-model parts of the pipeline.

This does NOT require ultralytics/torch -- it proves that a box drawn on a
synthetic "original" frame survives preprocessing (letterbox resize) and
post-processing (confidence filter + NMS + rescale) and lands back at
(approximately) its original coordinates. This is the same round-trip
`infer()` in Section 10.4 of the strategy document performs around the
actual model call.

Run: python demo_pipeline.py
"""
import sys

import numpy as np

sys.path.insert(0, "src")

from postprocessing import postprocess  # noqa: E402
from preprocessing import preprocess  # noqa: E402


def main():
    # A synthetic 1280x720 "original" frame with one object drawn at a known box.
    original_h, original_w = 720, 1280
    true_box = np.array([300.0, 200.0, 500.0, 400.0])  # x1, y1, x2, y2 in original pixels
    frame = np.full((original_h, original_w, 3), 60, dtype=np.uint8)  # dim background
    frame[int(true_box[1]) : int(true_box[3]), int(true_box[0]) : int(true_box[2])] = 220

    # Step 1: preprocessing (Section 6 / 10.1)
    tensor, scale, pad_offset = preprocess(frame, target_size=640)
    print(f"Preprocessed tensor shape: {tensor.shape}  scale={scale:.4f}  pad_offset={pad_offset}")

    # Step 2: simulate what the model would predict in the *letterboxed* frame.
    # We map the true box into letterboxed coordinates to fabricate a "prediction",
    # since no trained weights are available in this environment.
    pad_x, pad_y = pad_offset
    fake_pred_box = np.array(
        [
            [
                true_box[0] * scale + pad_x,
                true_box[1] * scale + pad_y,
                true_box[2] * scale + pad_x,
                true_box[3] * scale + pad_y,
            ],
            # a near-duplicate, slightly-shifted box NMS should suppress
            [
                true_box[0] * scale + pad_x + 2,
                true_box[1] * scale + pad_y + 2,
                true_box[2] * scale + pad_x,
                true_box[3] * scale + pad_y,
            ],
        ]
    )
    fake_scores = np.array([0.91, 0.77])
    fake_class_ids = np.array([0, 0])  # "car"

    # Step 3: post-processing (Section 10.5 / 11) back to original coordinates.
    boxes_out, scores_out, class_ids_out = postprocess(
        fake_pred_box, fake_scores, fake_class_ids, scale, pad_offset, conf_thresh=0.4, iou_thresh=0.45
    )

    print(f"Detections after NMS: {len(boxes_out)} (expected 1, duplicate suppressed)")
    print(f"Recovered box:  {boxes_out[0]}")
    print(f"Original box:   {true_box}")

    error = np.abs(boxes_out[0] - true_box).max()
    print(f"Max coordinate error after round-trip: {error:.3f} px")
    assert error < 1.0, "round-trip error too large"
    print("\nRound-trip OK: preprocessing + postprocessing correctly recover the original box.")


if __name__ == "__main__":
    main()
