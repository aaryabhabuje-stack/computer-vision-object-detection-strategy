# Real-Time Traffic Object Detection — Reference Implementation

This is the working code build of the project strategy in
*Real-Time Object Detection for Smart Traffic Surveillance*. It implements
every pipeline stage described there in real, runnable Python — preprocessing,
augmentation, and post-processing are plain NumPy/OpenCV with no ML framework
dependency; training and inference wrap the `ultralytics` YOLOv8n API.

## Project layout

```
traffic-detection/
├── configs/
│   └── traffic.yaml         # class taxonomy + dataset paths (Section 5.1)
├── src/
│   ├── preprocessing.py     # letterbox resize, CLAHE denoise, normalize (Section 6)
│   ├── augmentation.py      # flip/rotate/scale/crop/brightness/mosaic (Section 7)
│   ├── postprocessing.py    # IoU, NMS, confidence filter, rescale (Sections 10.5, 11)
│   ├── train.py             # training entry point (Section 8)
│   ├── infer.py             # real-time inference entry point (Sections 9-10)
│   └── utils.py             # class-name loading, box drawing
├── tests/
│   ├── test_preprocessing.py
│   └── test_postprocessing.py
├── demo_pipeline.py          # dependency-light round-trip demo (no model needed)
├── requirements.txt
└── data/                     # dataset goes here (see below) — empty in this build
```

## What actually runs right now, without a dataset or GPU

- `python -m pytest tests/` (or run each test file directly) — 13 unit tests
  covering preprocessing shape/range guarantees and NMS/IoU correctness.
- `python demo_pipeline.py` — proves the preprocess → (simulated detection) →
  post-process round-trip recovers the original box coordinates exactly.
- `src/augmentation.py` — every transform (flip, rotate, scale, crop,
  brightness/contrast, mosaic) has been smoke-tested against synthetic
  images and boxes.

These three are what a reviewer can execute immediately, with only
`numpy`, `opencv-python`, and `pyyaml` installed — no GPU, no dataset, no
`ultralytics` required.

## What requires a dataset + `ultralytics` to actually run

1. **Install the rest of the dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Assemble the dataset** per Section 5: images under
   `data/traffic/images/{train,val,test}` and YOLO-format labels under
   `data/traffic/labels/{train,val,test}`, split *by video clip* as described
   in Section 6.
3. **Train:**
   ```bash
   python src/train.py --config configs/traffic.yaml
   ```
   Uses the hyperparameters from Section 8.2 (SGD, lr0=0.01 with cosine
   decay, batch 16, 120 epochs, early-stop patience 20, 10-epoch backbone
   freeze) by default; every value is overridable via CLI flag.
4. **Run inference:**
   ```bash
   python src/infer.py --weights runs/traffic-yolov8n/weights/best.pt --source 0
   ```
   `--source` accepts a camera index or a video file path. `--conf` and
   `--iou` default to 0.4 / 0.45 (Section 11.2 / 11.4) and are tunable per
   deployment site.

## Design traceability

Every function's docstring references the strategy-document section it
implements, so a reviewer can go from a design decision in the report
straight to the code that realizes it, and back. In particular:

| Report section | Code |
|---|---|
| 6 — Preprocessing | `src/preprocessing.py` |
| 7 — Augmentation | `src/augmentation.py` |
| 8 — Training config | `src/train.py` |
| 10.4–10.5 — Inference / NMS pseudocode | `src/postprocessing.py`, `src/infer.py` |
| 13.1 — Unit tests | `tests/` |

## Known limitations of this build

- No dataset is bundled (`data/` is empty) — Section 5 describes the
  sourcing and annotation plan, but assembling ~15k labeled frames is
  outside what can be produced in this environment.
- `train.py` / `infer.py` cannot be executed end-to-end here without both a
  dataset and `ultralytics`/`torch` installed; they are included as a
  correct, ready-to-run wrapper around the documented hyperparameters, not
  as something already exercised against real data in this session.
- Everything else — preprocessing, augmentation, and post-processing — is
  fully executable and tested as-is, since these are the parts specified in
  enough detail (Sections 6, 7, 10.5) to implement without external data.
